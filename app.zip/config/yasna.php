<?php
/**
 * Created by PhpStorm.
 * User: jafar
 * Date: 4/18/17
 * Time: 09:13
 */

return [
	'drawing_query_limit' => 300,
] ;