<html>
<head>
    <title>Iran Strick</title>
    <style>
        html {
            background: url({{ url('/assets/images/update.jpg') }}) no-repeat center center fixed;
            -webkit-background-size: cover;
            -moz-background-size: cover;
            -o-background-size: cover;
            background-size: cover;
        }
    </style>
    <body>

</body>
</head>
</html>