<li>
	<a href="{{$target or '#'}}">
		<i class="fa fa-{{$icon or 'circle'}} fa-fw"></i>
		{{ $caption or '...' }}
	</a>
</li>

