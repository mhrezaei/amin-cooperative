<section id="gift">
    <div class="container">
        <div class="row">
            @include('front.home.drawing_event')
            @include('front.home.drawing_form_section')
        </div>
    </div>
    <div class="event" style="background: transparent;"> </div>
</section>