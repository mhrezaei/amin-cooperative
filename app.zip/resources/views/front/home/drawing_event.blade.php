<div class="col-sm-8">
    {{ '', $event->spreadMeta() }}
    <div class="event-main"> <img src="{{ url($event->featured_image) }}"> </div>
</div>