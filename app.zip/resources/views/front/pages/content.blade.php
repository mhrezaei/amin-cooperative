<div class="page-content">
    <div class="container">
        <div class="row">
            <div class="col-sm-8 col-center">
                {{ '', $page->spreadMeta() }}
                {!! $page->text !!}
            </div>
        </div>
    </div>
</div>