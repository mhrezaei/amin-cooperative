<!-- Load Scripts -->
{!! Html::script ('assets/libs/persian-calender/calendar.js') !!}
{!! Html::script ('assets/libs/persian-calender/jquery.ui.datepicker-cc.js') !!}
{!! Html::script ('assets/libs/persian-calender/jquery.ui.datepicker-cc-fa.js') !!}