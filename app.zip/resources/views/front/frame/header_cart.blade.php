{{--<div class="cart">--}}
    {{--<a href="#" class="icon-cart"></a>--}}
{{--</div>--}}
{{--<div class="cart full">--}}
    {{--<a href="#" class="icon-cart" data-notify="۳"></a>--}}
{{--</div>--}}