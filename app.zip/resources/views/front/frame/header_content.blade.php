<!-- Header -->
<header id="main-header">
    @include('front.frame.header_top_bar')
    @include('front.frame.header_logo_part')
</header>
@yield('navbar')