<div class="f-r">
    <div class="contact"> <i class="icon-phone"></i> {{ setting()->ask('telephone')->gain() }} </div>
</div>