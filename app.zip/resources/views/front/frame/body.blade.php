<body>
@include('front.frame.header_content')
@yield('content')
@include('front.frame.footer')
</body>
</html>