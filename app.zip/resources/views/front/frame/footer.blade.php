<footer id="main-footer">
    <div class="container">
        @include('front.frame.footer_logo')
        @include('front.frame.footer_menu')
        @include('front.frame.footer_copy_right')
    </div>
</footer>
@include('front.frame.jui_scripts')