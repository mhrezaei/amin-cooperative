<div id="logo-part">
    <div class="container">
        @include('front.frame.header_logo')
        @include('front.frame.header_cart')
        @include('front.frame.header_main_menu')
    </div>
</div>