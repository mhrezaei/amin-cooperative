<ul class="menu-footer">
    <li><a href="{{ url_locale('') }}"> {{ trans('front.home') }} </a></li>
    <li><a href="{{ url_locale('page/about') }}"> {{ trans('front.about') }} </a></li>
    <li><a href="{{ url_locale('products') }}"> {{ trans('front.products') }} </a></li>
    <li><a href="{{ url_locale('page/contact') }}"> {{ trans('front.contact_us') }} </a></li>
</ul>