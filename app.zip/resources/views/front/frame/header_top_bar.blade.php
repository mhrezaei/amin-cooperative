<div id="topbar">
    <div class="container">
        @include('front.frame.header_top_bar_tel_contact')
        <div class="f-l">
            @include('front.frame.header_top_bar_select_lang')
            @include('front.frame.header_top_bar_login_register_btn')
            @include('front.frame.header_top_bar_user_menu')
        </div>
    </div>
</div>