<div class="col-sm-3">
    {{--<div class="category-filters">--}}
        {{--<div class="title"> فیلترها </div>--}}
        {{--<article>--}}
            {{--<div class="field mb0"> <label class="label-big"> دسته‌ها </label>--}}
                {{--<div class="checkbox blue mb10"> <input id="check-1" type="checkbox" checked=""> <label for="check-1"> پسته </label> </div>--}}
                {{--<div class="checkbox blue mb10"> <input id="check-2" type="checkbox"> <label for="check-2"> بادام </label> </div>--}}
                {{--<div class="checkbox blue mb10"> <input id="check-3" type="checkbox" checked=""> <label for="check-3"> فندق </label> </div>--}}
                {{--<div class="checkbox blue mb10"> <input id="check-4" type="checkbox"> <label for="check-4">  تخمه</label> </div>--}}
                {{--<div class="checkbox blue mb10"> <input id="check-5" type="checkbox"> <label for="check-5"> سایر محصولات </label> </div>--}}
            {{--</div>--}}
            {{--<hr class="small">--}}
            {{--<div class="field with-switch"> <label for="switch-a-5"> موجود </label>--}}
                {{--<div class="switch d-ib blue "> <input id="switch-a-5" type="checkbox" checked=""> <label for="switch-a-5"></label> </div>--}}
            {{--</div>--}}
            {{--<div class="field with-switch"> <label for="switch-a-5"> فروش ویژه </label>--}}
                {{--<div class="switch d-ib blue"> <input id="switch-a-2" type="checkbox"> <label for="switch-a-2"></label> </div>--}}
            {{--</div>--}}
        {{--</article>--}}
    {{--</div>--}}
</div>