@extends('templates.email.email_frame')

@section('email_content')
	سفیر گرامی، {{ $volunteer_name }}
	<br>
	حساب کاربری شما در سامانه اهدای عضو فعال گردید.
	<br>
@endsection