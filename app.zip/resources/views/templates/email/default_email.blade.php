@extends('templates.email.email_frame')

@section('email_content')
    {{ $text }}
@endsection