@extends('templates.email.email_frame')

@section('email_content')
	{{ $data }}
@endsection