<?php $__env->startSection('error_code'); ?>
	<?php echo e($error = 403); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('message'); ?>
	<?php echo e(trans("validation.http.Error".$error)); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('errors.full_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>