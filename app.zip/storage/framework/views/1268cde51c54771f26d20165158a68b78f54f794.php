<?php if(0): ?>
	<div>
		<?php endif; ?>

		<?php echo Form::close(); ?>

	</div>
