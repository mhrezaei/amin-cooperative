


<?php echo $__env->make("templates.modal.start" , [
	'partial' => false,
	'modal_title' => trans('posts.form.refer_back'),
	'no_validation' => "1",
	'modal_id' => "modalPostReject",
	'modal_size' => "m",
], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="modal-body">
		<?php echo $__env->make("forms.textarea" , [
			'name' => "",
			'label' => trans('validation.attributes.moderate_note'),
			'id' => "txtModerateNote2",
			'class' => "form_required",
		], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<?php echo $__env->make('forms.group-start', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			<?php echo $__env->make('forms.button' , [
				'label' => trans('posts.form.refer_back'),
				'shape' => 'warning',
				'link' => 'postsAction("submit_reject")',
			], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			<?php echo $__env->make('forms.button' , [
				'label' => trans('forms.button.cancel'),
				'shape' => 'link',
				'link' => '$(".modal").modal("hide")',
			], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<?php echo $__env->make('forms.group-end' , [
//			'no_form' => "1",
		], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	</div>


<?php echo $__env->make("templates.modal.end", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>