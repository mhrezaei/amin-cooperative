<?php echo $__env->make('forms.textarea' , [
	'hint' => trans('forms.data_type.array_hint') ,
], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>