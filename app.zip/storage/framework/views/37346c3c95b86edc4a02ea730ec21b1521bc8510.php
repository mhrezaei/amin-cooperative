<?php if(sizeof($categories)): ?>
    <div id="categories">
        <div class="container">
            <div class="part-title">
                <h3> <span><?php echo e(trans('front.categories')); ?></span> <?php echo e(trans('front.products')); ?> </h3> </div>
            <div class="cats">
                <div class="row">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e('', $cat->spreadMeta()); ?>

                        <div class="col-sm-4">
                            <a href="<?php echo e(url_locale('products/categories/' . $cat->slug)); ?>" class="category-item">
                                <img src="<?php echo e(url($cat->image)); ?>">
                                <div class="more"> <svg width="100%" height="100%" viewBox="0 0 220 42" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                        <polygon id="Rectangle" stroke="none" fill-opacity="0.802026721" fill="#000000" fill-rule="evenodd" points="0 0 220 0 178 42 3.55271368e-15 42"></polygon>
                                    </svg> <span> <?php echo e(trans('front.show_products')); ?> </span> </div>
                                <div class="cat-name"> <svg width="100%" height="100%" viewBox="0 0 220 42" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                        <polygon id="Rectangle" stroke="none" fill-opacity="0.802026721" fill="#31415B" fill-rule="evenodd" points="42 0 220 0 220 42 0 42"></polygon>
                                    </svg> <span> <?php echo e($cat->title); ?> </span> </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>