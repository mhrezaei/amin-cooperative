

	
		
		
		
		
	



	
		
		
		

	


<?php echo $__env->make('manage.frame.widgets.topbar' , [
	'icon' => 'user' ,
	'color' => 'grey' ,
	'text' => Auth::user()->full_name ,
	'items' => [
		['manage/account' , trans('settings.account') , 'sliders'] ,
		['-'] ,
		['/logout' , trans('manage.logout') , 'sign-out'] ,
	]
], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
