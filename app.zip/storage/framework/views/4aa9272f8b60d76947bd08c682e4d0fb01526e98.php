<ul class="menu">
    <li><a href="<?php echo e(url_locale('')); ?>"> <?php echo e(trans('front.home')); ?> </a></li>
    <li><a href="<?php echo e(url_locale('page/about')); ?>"> <?php echo e(trans('front.about')); ?> </a></li>
    <li> <a href="<?php echo e(url_locale('products')); ?>"> <?php echo e(trans('front.products')); ?> </a>
    
        
            
            
            
            
        
    </li>
    <li><a href="<?php echo e(url_locale('page/contact')); ?>"> <?php echo e(trans('front.contact_us')); ?> </a></li>
</ul>