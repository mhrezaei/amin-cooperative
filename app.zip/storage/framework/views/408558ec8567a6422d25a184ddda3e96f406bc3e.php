<?php $__env->startSection('head'); ?>
    <title><?php echo e(setting()->ask('site_title')->gain()); ?> | <?php echo e(trans('front.products')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('front.frame.navbar',
    [
        'array' =>
        [
            [trans('front.home'), url_locale('')],
            [trans('front.products'), url_locale('products')],
            [$folder->title, url_locale('products/categories/' . $folder->slug)],
        ],
        'title' => $folder->title
    ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('front.products.products.content', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.frame.frame', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>