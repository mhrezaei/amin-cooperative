<?php echo $__env->make("manage.posts.editor-title", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make("manage.posts.editor-text", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make("manage.posts.editor-price", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make("manage.posts.editor-meta", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
