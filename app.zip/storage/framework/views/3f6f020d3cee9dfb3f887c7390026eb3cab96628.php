<div class="field">
    <label> <?php echo e(trans('validation.attributes.' . $name)); ?> </label>
    <input type="<?php echo e(isset($type) ? $type : ''); ?>" name="<?php echo e(isset($name) ? $name : ''); ?>" id="<?php echo e(isset($name) ? $name : ''); ?>" class="<?php echo e(isset($class) ? $class : ''); ?>"
           placeholder="<?php echo e(trans('validation.attributes.' . $name)); ?>"
           title="<?php echo e(trans('validation.attributes_example.' . $name)); ?>"
           minlength="<?php echo e(isset($min) ? $min : ''); ?>"
           maxlength="<?php echo e(isset($max) ? $max : ''); ?>"
           value="<?php echo e(isset($value) ? $value : ''); ?>"
           error-value="<?php echo e(trans('validation.javascript_validation.' . $name)); ?>"
            <?php echo e(isset($other) ? $other : ''); ?>>
</div>