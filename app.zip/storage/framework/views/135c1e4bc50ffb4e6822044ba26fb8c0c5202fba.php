<?php if($model->hasAnyOf(['template_choice','slug','visibility_choice'])): ?>

	<div class="panel panel-default">
		<div class="panel-heading">
			<?php echo e(trans('posts.form.options')); ?>

		</div>

		<div class="panel-body">

			


			<?php echo $__env->make("forms.select_self" , [
				'condition' => $model->has('template_choice'),
				'top_label' => trans('posts.form.template'),
				'name' => "template",
				'options' => $model->posttype->templatesCombo(),
				'value' => $model->template,
				'value_field' => "0",
				'caption_field' => "1",
			], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


			
			<?php echo $__env->make("forms.input-self" , [
				'condition' => $model->has('slug'),
				'top_label' => trans('validation.attributes.slug'),
				'name' => "slug",
				'value' => $model->slug,
				'class' => "ltr text-center",
				'placeholder' => "like_this",
				'on_blur' => "postsAction('check_slug')",
				'id' => "txtSlug",
			], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div id="divSlugFeedback"></div>

			
			<div class="m10"></div>
			<?php echo $__env->make("manage.posts.editor-visibility", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


		</div>


	</div>
<?php endif; ?>