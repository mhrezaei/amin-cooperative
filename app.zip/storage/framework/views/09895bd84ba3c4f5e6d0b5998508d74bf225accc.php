<?php echo $__env->make('manage.frame.widgets.grid-rowHeader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<td>
	<?php echo $__env->make("manage.frame.widgets.grid-text" , [
		'text' => $model->title,
		'link' => "modal:manage/upstream/edit/downstream/-id-",
	], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make("manage.frame.widgets.grid-badges" , [
		'badges' => [
			[
				'text' => $model->slug,
				'condition' => true,
				'icon' => "code",
				'color' => "default",
			],
		]
	], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</td>

<td>
<?php echo e(trans('forms.data_type.'.$model->data_type)); ?>

</td>

<td>
<?php echo e(trans('settings.categories.'.$model->category)); ?>

<?php echo $__env->make("manage.frame.widgets.grid-badges" , [
	'badges' => [
		[
			'text' => trans('settings.is_resident'),
			'condition' => $model->is_resident,
			'icon' => "bookmark",
			'color' => "success",
		],
		[
			'text' => trans('settings.developers_only'),
			'condition' => $model->developers_only,
			'icon' => "github-alt",
			'color' => "warning",
		],
		[
			'text' => trans('settings.is_localized'),
			'condition' => $model->is_localized,
			'icon' => "globe",
			'color' => "info",
		],
	],
], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</td>

<td>
	<?php echo $__env->make("manage.frame.widgets.grid-text" , [
		'text' => trans('forms.button.set'),
		'link' => "modal:manage/upstream/downstream/-id-",
		'class' => "btn btn-default",
		'icon' => "eye",
	], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
</td>