<div id="logo-part">
    <div class="container">
        <?php echo $__env->make('front.frame.header_logo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('front.frame.header_cart', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('front.frame.header_main_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>