<header class="profile-header">
    <div class="container">
        <div class="avatar tac"> <img src="<?php echo e(url('/assets/images/user.svg')); ?>" width="64"> </div>
        <h2 class="name"> <?php echo e(user()->full_name); ?> </h2>
        <span class="label alt green md"> <?php echo e(trans('front.all_user_score')); ?> <strong><?php echo e(pd(floor(user()->sum_receipt_amount / 500000))); ?></strong> </span>
        <div class="profile-tabs">
            <div class="tab <?php echo e(isset($dashboard) ? $dashboard : ''); ?>">
                <a href="<?php echo e(url_locale('user/dashboard')); ?>"> <span class="icon-dashboard"></span> <?php echo e(trans('manage.dashboard')); ?> </a>
            </div>
            <div class="tab <?php echo e(isset($orders) ? $orders : ''); ?>">
                <a href="#"> <span class="icon-cart"></span> <?php echo e(trans('front.orders')); ?> </a>
            </div>
            <div class="tab <?php echo e(isset($profile) ? $profile : ''); ?>">
                <a href="<?php echo e(url_locale('user/profile')); ?>"> <span class="icon-pencil"></span> <?php echo e(trans('front.edit_profile')); ?> </a>
            </div>
            <div class="tab <?php echo e(isset($accepted_code) ? $accepted_code : ''); ?>">
                <a href="<?php echo e(url_locale('user/drawing')); ?>"> <span class="icon-tag"></span> <?php echo e(trans('front.accepted_codes')); ?> </a>
            </div>
            <div class="tab <?php echo e(isset($events) ? $events : ''); ?>">
                <a href="<?php echo e(url_locale('user/events')); ?>"> <span class="icon-calendar"></span> <?php echo e(trans('front.events')); ?> </a>
            </div>
        </div>
    </div>
</header>