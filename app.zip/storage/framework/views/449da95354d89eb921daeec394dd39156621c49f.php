<?php $__env->startSection('head'); ?>
    <title><?php echo e(setting()->ask('site_title')->gain()); ?> | <?php echo e(trans('front.accepted_codes')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('front.frame.navbar',
    [
        'array' =>
        [
            [trans('front.home'), url_locale('')],
            [trans('front.accepted_codes'), url_locale('user/drawing')],
        ]
    ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content profile">
        <?php echo $__env->make('front.user.frame.user_dashboars_header', ['accepted_code' => 'active'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('front.user.drawing.content', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.frame.frame', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>