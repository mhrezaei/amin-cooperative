<?php echo $__env->make('front.frame.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<title>
    <?php echo e(setting()->ask('site_title')->gain()); ?> | <?php echo e(trans('front.register')); ?>

</title>
<body class="auth">
<div class="auth-wrapper">
    <div class="auth-col">
        <a href="<?php echo e(url_locale('')); ?>" class="logo"> <img src="<?php echo e(url('/assets/images/logo.png')); ?>"> </a>
    </div>
    <div class="auth-col">
        <h1 class="auth-title"> <?php echo e(trans('front.register')); ?> </h1>
            <?php echo Form::open([
                'url'	=> '/register/new' ,
                'method'=> 'post',
                'class' => 'form-horizontal js',
                'name' => 'registerForm',
                'id' => 'registerForm',
            ]); ?>


            <?php echo $__env->make('auth.field', [
                'name' => 'name_first',
                'other' => 'autofocus',
                'type' => 'text',
                'value' => old('name_first'),
                'class' => 'form-required form-persian',
                'min' => 2,
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->make('auth.field', [
                'name' => 'name_last',
                'type' => 'text',
                'value' => old('name_last'),
                'class' => 'form-required form-persian',
                'min' => 2,
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->make('auth.field', [
                'name' => 'code_melli',
                'type' => 'text',
                'value' => old('code_melli'),
                'class' => 'form-required form-national',
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->make('auth.field', [
                'name' => 'mobile',
                'type' => 'text',
                'value' => old('mobile'),
                'class' => 'form-required form-mobile',
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->make('auth.field', [
                'name' => 'password',
                'type' => 'password',
                'value' => old('password'),
                'class' => 'form-required form-password',
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->make('auth.field', [
                'name' => 'password2',
                'type' => 'password',
                'value' => old('password2'),
                'class' => 'form-required',
                
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="tal" style="margin-bottom: 15px;">
                <button class="green block" type="submit"> <?php echo e(trans('front.register')); ?> </button>
            </div>
            <?php echo $__env->make('forms.feed', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <hr class="or">
            <div class="tal" style="margin-bottom: 15px;">
                <button onclick="window.location = '<?php echo e(url('/login')); ?>';" class="blue block"> <?php echo e(trans('front.member_login')); ?> </button>
            </div>

        <?php echo Form::close(); ?>

    </div>
</div>
</div>
<?php echo $__env->make('front.frame.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

</html>