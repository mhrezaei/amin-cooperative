<?php $__env->startSection('head'); ?>
    <title><?php echo e(setting()->ask('site_title')->gain()); ?> | <?php echo e(trans('front.home')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('front.home.slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('front.home.mouse_spacer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('front.home.about', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('front.home.categories', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('front.home.drawing', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.frame.frame', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>