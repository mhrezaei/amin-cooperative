<?php if($about): ?>
    <?php echo e('', $about->spreadMeta()); ?>

<div id="home-about">
    <div class="container">
        <div class="row">
            <div class="col-sm-8 col-center">
                <p style="text-align: justify;"><?php echo e($about->abstract); ?></p>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>