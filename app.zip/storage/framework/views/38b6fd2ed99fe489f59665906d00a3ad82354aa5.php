<?php if(sizeof($events)): ?>
<div class="container">
    <div class="row">
        <div class="col-sm-8 col-center">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e('', $event->spreadMeta()); ?>

            <section class="panel event-item">
                <header>
                    <div class="title"> <?php echo e($event->title); ?> </div>
                    <div class="functions">
                        <div class="label red alt"> <?php echo e(trans('front.to')); ?> <?php echo e(echoDate($event->end_time, 'j F Y', 'auto', true)); ?> </div>
                        <div class="label green alt"> <?php echo e(trans('front.all_user_score')); ?>: <?php echo e(pd(floor(user()->sum_receipt_amount / 500000))); ?> </div>
                    </div>
                </header>
                <article>
                    <?php echo $event->text; ?>

                </article>
            </section>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endif; ?>