<?php if(sizeof($slideshow)): ?>
<div id="home-slides">
    <ul class="home-slides">
        <?php $__currentLoopData = $slideshow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e('', $slide->spreadMeta()); ?>

        <li class="home-slide" style="background-image: url(<?php echo e(url($slide->featured_image)); ?>);">
            <div class="container">
                <div class="content">
                    <?php if(strlen($slide->title2)): ?>
                        <h1> <?php echo e($slide->title2); ?> </h1>
                    <?php endif; ?>
                    <?php if(strlen($slide->abstract)): ?>
                        <p> <?php echo e($slide->abstract); ?> </p>
                    <?php endif; ?>
                </div>
            </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>